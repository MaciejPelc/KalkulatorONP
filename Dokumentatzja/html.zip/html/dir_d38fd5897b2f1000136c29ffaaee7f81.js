var dir_d38fd5897b2f1000136c29ffaaee7f81 =
[
    [ "netcoreapp3.1", "dir_3ad81eba1a9c7c4dd652b6d0956403f8.html", "dir_3ad81eba1a9c7c4dd652b6d0956403f8" ]
];