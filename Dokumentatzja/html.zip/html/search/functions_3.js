var searchData=
[
  ['main_57',['Main',['../classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a3830ca4c5aef33a7b9301d6b90657799',1,'superFajnyKalkulatorPodejscie2::Calculator']]]
];
