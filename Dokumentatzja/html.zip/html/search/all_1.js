var searchData=
[
  ['additioninfix_1',['additionInfix',['../class_calculator_tests_1_1_tests.html#a3ce0a4e7dd6c05a892412c30a2892f41',1,'CalculatorTests::Tests']]],
  ['additionpostfix_2',['additionPostfix',['../class_calculator_tests_1_1_tests.html#ac5762ddb3e49c5226efbeb5976cd50be',1,'CalculatorTests::Tests']]]
];
