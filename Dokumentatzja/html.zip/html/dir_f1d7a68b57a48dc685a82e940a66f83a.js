var dir_f1d7a68b57a48dc685a82e940a66f83a =
[
    [ "netcoreapp3.1", "dir_85fe46b2e64093ce3c1578b0a4b449a1.html", "dir_85fe46b2e64093ce3c1578b0a4b449a1" ]
];