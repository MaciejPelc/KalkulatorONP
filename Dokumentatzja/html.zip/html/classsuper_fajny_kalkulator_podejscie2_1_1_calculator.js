var classsuper_fajny_kalkulator_podejscie2_1_1_calculator =
[
    [ "evalrpn", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a705534ca8bbfd5d81e1171c53a1a3228", null ],
    [ "fromRPN", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#aa960a6a2795104d758f3592fb219953c", null ],
    [ "Main", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a3830ca4c5aef33a7b9301d6b90657799", null ],
    [ "toRPN", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a1eb2cd1583f9eab1995483ea23606e12", null ],
    [ "translateInServer", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a71931f0a16f076c0b1e9f0b33a312836", null ],
    [ "translateToServer", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a9235b8747f537339091ef0ea0f0efc6d", null ]
];