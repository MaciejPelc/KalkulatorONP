var searchData=
[
  ['superfajnykalkulatorpodejscie2_39',['superFajnyKalkulatorPodejscie2',['../namespacesuper_fajny_kalkulator_podejscie2.html',1,'']]]
];
