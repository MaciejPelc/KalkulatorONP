var searchData=
[
  ['kalkulator5_2e0_2eassemblyinfo_2ecs_23',['Kalkulator5.0.AssemblyInfo.cs',['../_kalkulator5_80_8_assembly_info_8cs.html',1,'']]]
];
