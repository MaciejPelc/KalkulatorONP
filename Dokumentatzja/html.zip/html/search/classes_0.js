var searchData=
[
  ['calculator_36',['Calculator',['../classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html',1,'superFajnyKalkulatorPodejscie2']]]
];
