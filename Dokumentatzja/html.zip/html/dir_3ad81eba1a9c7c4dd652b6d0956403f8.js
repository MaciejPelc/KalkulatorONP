var dir_3ad81eba1a9c7c4dd652b6d0956403f8 =
[
    [ ".NETCoreApp,Version=v3.1.AssemblyAttributes.cs", "_calculator_tests_2obj_2_debug_2netcoreapp3_81_2_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html", null ],
    [ "CalculatorTests.AssemblyInfo.cs", "_calculator_tests_8_assembly_info_8cs.html", null ]
];