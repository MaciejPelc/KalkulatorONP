var annotated_dup =
[
    [ "CalculatorTests", "namespace_calculator_tests.html", [
      [ "Tests", "class_calculator_tests_1_1_tests.html", "class_calculator_tests_1_1_tests" ]
    ] ],
    [ "superFajnyKalkulatorPodejscie2", "namespacesuper_fajny_kalkulator_podejscie2.html", [
      [ "Calculator", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator" ]
    ] ]
];