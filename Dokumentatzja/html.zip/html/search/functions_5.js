var searchData=
[
  ['torpn_59',['toRPN',['../classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a1eb2cd1583f9eab1995483ea23606e12',1,'superFajnyKalkulatorPodejscie2::Calculator']]],
  ['translateinserver_60',['translateInServer',['../classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a71931f0a16f076c0b1e9f0b33a312836',1,'superFajnyKalkulatorPodejscie2::Calculator']]],
  ['translatetoserver_61',['translateToServer',['../classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html#a9235b8747f537339091ef0ea0f0efc6d',1,'superFajnyKalkulatorPodejscie2::Calculator']]]
];
