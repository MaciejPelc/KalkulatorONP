var searchData=
[
  ['substractinfix_70',['substractInfix',['../class_calculator_tests_1_1_tests.html#a5f0a706269339fe6e330ce6d100bceea',1,'CalculatorTests::Tests']]],
  ['substractpostfix_71',['substractPostfix',['../class_calculator_tests_1_1_tests.html#a398b008ecb72845f8fc32481cabf23c7',1,'CalculatorTests::Tests']]]
];
