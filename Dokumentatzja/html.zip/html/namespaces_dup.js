var namespaces_dup =
[
    [ "CalculatorTests", "namespace_calculator_tests.html", "namespace_calculator_tests" ],
    [ "superFajnyKalkulatorPodejscie2", "namespacesuper_fajny_kalkulator_podejscie2.html", "namespacesuper_fajny_kalkulator_podejscie2" ]
];