var files_dup =
[
    [ "CalculatorTests", "dir_c8fcd245120dede0dc4a3085b493902d.html", "dir_c8fcd245120dede0dc4a3085b493902d" ],
    [ "Kalkulator5.0", "dir_3ee90f9a1bf09364ab42884e0915ef5b.html", "dir_3ee90f9a1bf09364ab42884e0915ef5b" ]
];