var searchData=
[
  ['setup_28',['Setup',['../class_calculator_tests_1_1_tests.html#a880549a54353463bbe3563382020388a',1,'CalculatorTests::Tests']]],
  ['substractinfix_29',['substractInfix',['../class_calculator_tests_1_1_tests.html#a5f0a706269339fe6e330ce6d100bceea',1,'CalculatorTests::Tests']]],
  ['substractpostfix_30',['substractPostfix',['../class_calculator_tests_1_1_tests.html#a398b008ecb72845f8fc32481cabf23c7',1,'CalculatorTests::Tests']]],
  ['superfajnykalkulatorpodejscie2_31',['superFajnyKalkulatorPodejscie2',['../namespacesuper_fajny_kalkulator_podejscie2.html',1,'']]]
];
