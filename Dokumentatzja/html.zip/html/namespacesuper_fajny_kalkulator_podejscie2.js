var namespacesuper_fajny_kalkulator_podejscie2 =
[
    [ "Calculator", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator.html", "classsuper_fajny_kalkulator_podejscie2_1_1_calculator" ]
];