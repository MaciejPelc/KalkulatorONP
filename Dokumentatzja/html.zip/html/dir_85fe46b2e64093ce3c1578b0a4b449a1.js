var dir_85fe46b2e64093ce3c1578b0a4b449a1 =
[
    [ ".NETCoreApp,Version=v3.1.AssemblyAttributes.cs", "_kalkulator5_80_2obj_2_debug_2netcoreapp3_81_2_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html", null ],
    [ "Kalkulator5.0.AssemblyInfo.cs", "_kalkulator5_80_8_assembly_info_8cs.html", null ]
];